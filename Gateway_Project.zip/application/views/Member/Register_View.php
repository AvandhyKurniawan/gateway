<html>
	<head>
	<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Beranda | Gateway Apartment</title>
        <link rel="shortcut icon" href="<?= base_url("support/template/assets/images/Logo.png"); ?>">

        <link href="<?= base_url("support/template/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" type="text/css">
        <link href="<?= base_url("support/template/assets/css/metismenu.min.css"); ?>" rel="stylesheet" type="text/css">
        <link href="<?= base_url("support/template/assets/css/icons.css"); ?>" rel="stylesheet" type="text/css">
        <link href="<?= base_url("support/template/assets/css/style.css"); ?>" rel="stylesheet" type="text/css">
		<link href="<?= base_url("support/template/plugins/icheck-material/icheck-material.min.css"); ?>" rel="stylesheet" type="text/css">
	</head>

	<body>
		<!-- Begin page -->
        <div class="container-fluid">
			<div class="row justify-content-center">
				<div class="col-1">
					<!-- <div class="m-t-0 m-b-15">
						<a href="<?= base_url("/"); ?>" class="logo logo-admin"><img src="<?= base_url("support/template/assets/images/Logo.png"); ?>" alt=""></a>
					</div> -->
				</div>
				<div class="col-20">
					<div class="card card-pages shadow-none">
						<div class="card-body">
						<div class="user-thumb text-center">
							<img src="<?= base_url("support/template/assets/images/Logo.png"); ?>" class="thumb-lg img-thumbnail mx-auto d-block img-fluid" alt="thumbnail">
						</div>
							<h5 class="font-18 text-center">Pendaftaran Peserta RUAT</h5>
	
							<div class="row">
								<div class="col-12">
									<div class="form-group">
										<label>NAMA</label>
										<input class="form-control" type="text" id="txtNamaLengkap" name="txtNamaLengkap" placeholder="Nama Lengkap">
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>UNIT</label>
										<div class="row">
											<div class="col-4">
												<select name="cmbTower" id="cmbTower" class="form-control">
													<option value="">TOWER</option>
												</select>
											</div>
											<div class="col-4">
												<select name="cmbLantai" id="cmbLantai" class="form-control">
													<option value="">LANTAI</option>
												</select>
											</div>
											<div class="col-4">
												<select name="cmbNomor" id="cmbNomor" class="form-control">
													<option value="">NOMOR</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>STATUS</label>
										<select name="cmbStatus" id="cmbStatus" class="form-control">
											<option value="">STATUS</option>
										</select>
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>DOMISILI</label>
										<input class="form-control" type="text" id="txtDomisili" name="txtDomisili" placeholder="Domisili">
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>ALAMAT KTP</label>
										<input class="form-control" type="text" id="txtAlamat" name="txtAlamat" placeholder="Alamat Sesuai KTP">
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>NO HP</label>
										<input class="form-control" type="text" id="txtNoHp" name="txtNoHp" placeholder="Nomor Handphone">
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>EMAIL</label>
										<input class="form-control" type="text" id="txtEmail" name="txtEmail" placeholder="Email">
									</div>
								</div>
								<div class="col-12">
									<div class="form-group">
										<label>LAMPIRAN DOKUMEN</label>
										<div class="row">
											<div class="col-6">
												<div class="icheck-material-blue">
													<input type="radio" id="rbLampiranPemilik" name="rbLampiran" />
													<label for="rbLampiranPemilik">PEMILIK</label>
												</div>
												<div class="row">
													<div class="col-12">
														<div class="form-group">
															<label for="fileKtpPemilik">KTP</label>
															<input type="file" name="fileKtpPemilik" id="fileKtpPemilik" class="form-control">
														</div>
														<div class="form-group">
															<label for="fileFotoDiriPemilik">FOTO DIRI</label>
															<input type="file" name="fileFotoDiriPemilik" id="fileFotoDiriPemilik" class="form-control">
														</div>
													</div>
												</div>
											</div>
											<div class="col-6">
												<div class="icheck-material-blue">
													<input type="radio" id="rbLampiranWakil" name="rbLampiran" />
													<label for="rbLampiranWakil">WAKIL</label>
												</div>
												<div class="row">
													<div class="col-12">
														<div class="form-group">
															<label for="fileKtpWakil">KTP</label>
															<input type="file" name="fileKtpWakil" id="fileKtpWakil" class="form-control">
														</div>
														<div class="form-group">
															<label for="fileFotoDiriWakil">FOTO DIRI</label>
															<input type="file" name="fileFotoDiriWakil" id="fileFotoDiriWakil" class="form-control">
														</div>
														<div class="form-group">
															<label for="fileSuratKuasa">SURAT KUASA</label>
															<input type="file" name="fileSuratKuasa" id="fileSuratKuasa" class="form-control">
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
	
							<div class="row justify-content-center">
								<div class="col-md-6 col-sm-12">
									<button class="btn btn-primary btn-block btn-lg waves-effect waves-light">Daftar</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        </div>
        <!-- END wrapper -->

        <!-- jQuery  -->
        <script src="<?= base_url("support/template/assets/js/jquery.min.js"); ?>"></script>
        <script src="<?= base_url("support/template/assets/js/bootstrap.bundle.min.js"); ?>"></script>
        <script src="<?= base_url("support/template/assets/js/metismenu.min.js"); ?>"></script>
        <script src="<?= base_url("support/template/assets/js/jquery.slimscroll.js"); ?>"></script>
        <script src="<?= base_url("support/template/assets/js/waves.min.js"); ?>"></script>

        <!-- App js -->
        <script src="<?= base_url("support/template/assets/js/app.js"); ?>"></script>
	</body>
</html>
